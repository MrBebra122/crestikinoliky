package com.example.tictac;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class MainActivity extends AppCompatActivity {
    // Объявление переменных для работы с сохраненными данными
    SharedPreferences stats; // Хранит статистику игры
    SharedPreferences themeSettings; // Хранит настройки темы
    SharedPreferences.Editor editorSettings; // Редактор для обновления настроек темы

    ImageButton imageTheme; // Кнопка для переключения темы
    TextView tvStats; // Текстовое поле для отображения статистики
    Button btnChangeTheme, btnStartGame, btnStartGameWithBot; // Кнопки для изменения темы и начала игры

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); // Вызов родительского метода
        setContentView(R.layout.activity_main); // Установка разметки активности

        // Инициализация SharedPreferences
        stats = getSharedPreferences("TicTacToePrefs", MODE_PRIVATE);
        themeSettings = getSharedPreferences("SETTINGS", MODE_PRIVATE);

        // Включение режима Edge to Edge
        EdgeToEdge.enable(this);

        // Инициализация UI элементов
        tvStats = findViewById(R.id.tvStats);
        btnStartGame = findViewById(R.id.btnStartGame);
        btnStartGameWithBot = findViewById(R.id.btnStartGameWithBot);
        imageTheme = findViewById(R.id.imageBtn);

        // Обновление статистики и иконки темы
        updateStats();
        updateImageButton();

        // Установка обработчика клика для кнопки смены темы
        imageTheme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Проверка текущего состояния темы
                if (themeSettings.getBoolean("MODE_NIGHT_ON", false)) {
                    // Если тема темная, переключаем на светлую
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                    editorSettings = themeSettings.edit(); // Получаем редактор для изменения настроек
                    editorSettings.putBoolean("MODE_NIGHT_ON", false); // Сохраняем состояние
                    editorSettings.apply(); // Применяем изменения
                    Toast.makeText(MainActivity.this, "Темная тема отключена", Toast.LENGTH_SHORT).show();
                } else {
                    // Если тема светлая, переключаем на темную
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                    editorSettings = themeSettings.edit(); // Получаем редактор для изменения настроек
                    editorSettings.putBoolean("MODE_NIGHT_ON", true); // Сохраняем состояние
                    editorSettings.apply(); // Применяем изменения
                    Toast.makeText(MainActivity.this, "Темная тема включена", Toast.LENGTH_SHORT).show();
                }
                updateImageButton(); // Обновляем изображение кнопки темы
                recreate(); // Пересоздаем активность для применения изменений
            }
        });

        // Установка обработчика клика для кнопки начала игры без бота
        btnStartGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startGame(false); // Запуск игры без бота
            }
        });

        // Установка обработчика клика для кнопки начала игры с ботом
        btnStartGameWithBot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startGame(true); // Запуск игры с ботом
            }
        });
    }

    // Метод для обновления иконки темы в зависимости от текущих настроек
    private void updateImageButton() {
        if (themeSettings.getBoolean("MODE_NIGHT_ON", false)) {
            imageTheme.setImageResource(R.drawable.day_night); // Устанавливаем иконку для темной темы
        } else {
            imageTheme.setImageResource(R.drawable.day_night); // Устанавливаем иконку для светлой темы (по коду кажется, что эта иконка одна для обеих тем)
        }
    }

    // Метод для установки текущей темы при запуске
    private void setCurrentTheme() {
        if (themeSettings.getBoolean("MODE_NIGHT_ON", false)) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO); // Установка светлой темы
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES); // Установка темной темы
        }
    }

    // Метод запуска игры
    private void startGame(boolean withBot) {
        Intent intent = new Intent(this, TicTacActivity.class); // Создание намерения для перехода на другую активность
        intent.putExtra("withBot", withBot); // Передача информации о том, будет ли бот в игре
        startActivity(intent); // Запуск новой активности
    }

    // Метод для обновления статистики игры
    private void updateStats() {
        int wins = stats.getInt("wins", 0); // Получение количества побед
        int losses = stats.getInt("losses", 0); // Получение количества поражений
        int draws = stats.getInt("draws", 0); // Получение количества ничьих
        tvStats.setText("X Победы: " + wins + " | O Победы: " + losses + " | Ничьи: " + draws); // Обновление текста на экране
    }

    @Override
    protected void onResume() {
        super.onResume(); // Вызов родительского метода
        updateStats(); // Обновление статистики при возвращении в активность
    }
}
