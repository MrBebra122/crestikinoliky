package com.example.tictac;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class TicTacActivity extends AppCompatActivity {
    // SharedPreferences для хранения статистики игры
    SharedPreferences stats;

    // Флаг, указывающий, играет ли с игроком бот
    boolean withBot;

    // Игровое поле
    char[] board;

    // Текущий игрок ('X' или 'O')
    char currentPlayer;

    // Текстовое поле для отображения статуса игры
    TextView tvStatus;

    // Массив кнопок для игрового поля
    Button[] buttons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); // Вызов метода родительского класса
        setContentView(R.layout.activity_tic_tac); // Установка разметки активности

        // Инициализация SharedPreferences для статистики
        stats = getSharedPreferences("TicTacToePrefs", MODE_PRIVATE);
        // Получение флага о том, играет ли с игроком бот
        withBot = getIntent().getBooleanExtra("withBot", false);

        // Инициализация игрового поля и текущего игрока
        board = new char[9];
        currentPlayer = 'X'; // Игрок 'X' начинает игру

        // Инициализация UI элементов
        tvStatus = findViewById(R.id.tvStatus);
        buttons = new Button[9];

        // Инициализация кнопок игрового поля и установка обработчиков нажатий
        for (int i = 0; i < 9; i++) {
            String buttonID = "btn_" + i; // Формирование ID кнопки
            int resID = getResources().getIdentifier(buttonID, "id", getPackageName()); // Получение ресурса по имени
            buttons[i] = findViewById(resID); // Инициализация кнопки
            buttons[i].setOnClickListener(new ButtonClickListener(i)); // Установка слушателя для нажатия
        }

        // Обновление статуса игры
        updateStatus();
    }

    // Метод для обновления статуса игры
    private void updateStatus() {
        tvStatus.setText("Игрок " + currentPlayer + " ходит"); // Установка текста игры
    }

    // Метод для выполнения хода
    private void makeMove(int position) {
        // Проверяем, свободна ли ячейка
        if (board[position] == 0) {
            board[position] = currentPlayer; // Запоминаем ход текущего игрока
            buttons[position].setText(String.valueOf(currentPlayer)); // Обновляем текст кнопки

            // Проверяем условия для победы
            if (checkWin()) {
                updateStats(true); // Обновляем статистику при победе
                finish(); // Завершаем игру
            } else if (isDraw()) {
                updateStats(false); // Обновляем статистику при ничьей
                finish(); // Завершаем игру
            } else {
                // Смена игрока
                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X'; // Меняем текущего игрока
                updateStatus(); // Обновляем статус игры

                // Если игра с ботом и текущий игрок 'O', делаем ход бота
                if (withBot && currentPlayer == 'O') {
                    makeBotMove();
                }
            }
        }
    }

    // Метод для выполнения хода бота
    private void makeBotMove() {
        int position;
        do {
            position = (int) (Math.random() * 9); // Генерация случайной позиции
        } while (board[position] != 0); // Проверка, свободна ли позиция
        makeMove(position); // Выполнение хода бота
    }

    // Метод проверки победы
    private boolean checkWin() {
        // Проверяем все возможные варианты победы
        return (board[0] == currentPlayer && board[1] == currentPlayer && board[2] == currentPlayer) ||
                (board[3] == currentPlayer && board[4] == currentPlayer && board[5] == currentPlayer) ||
                (board[6] == currentPlayer && board[7] == currentPlayer && board[8] == currentPlayer) ||
                (board[0] == currentPlayer && board[3] == currentPlayer && board[6] == currentPlayer) ||
                (board[1] == currentPlayer && board[4] == currentPlayer && board[7] == currentPlayer) ||
                (board[2] == currentPlayer && board[5] == currentPlayer && board[8] == currentPlayer) ||
                (board[0] == currentPlayer && board[4] == currentPlayer && board[8] == currentPlayer) ||
                (board[2] == currentPlayer && board[4] == currentPlayer && board[6] == currentPlayer);
    }

    // Метод проверки ничьей
    private boolean isDraw() {
        // Если есть хотя бы одна свободная ячейка, значит игра продолжается
        for (char cell : board) {
            if (cell == 0) {
                return false;
            }
        }
        return true; // Все ячейки заняты — ничья
    }

    // Метод для обновления статистики игры
    private void updateStats(boolean isWin) {
        SharedPreferences.Editor editor = stats.edit(); // Получение редактора для изменения SharedPreferences
        int wins = stats.getInt("wins", 0); // Получение текущего количества побед
        int losses = stats.getInt("losses", 0); // Получение текущего количества поражений
        int draws = stats.getInt("draws", 0); // Получение текущего количества ничьих

        // Обновление статистики в зависимости от результата игры
        if (isWin) {
            if (currentPlayer == 'X') {
                editor.putInt("wins", wins + 1); // Увеличиваем количество побед для 'X'
            } else {
                editor.putInt("losses", losses + 1); // Увеличиваем количество поражений для 'O'
            }
        } else {
            editor.putInt("draws", draws + 1); // Увеличиваем количество ничьих
        }
        editor.apply(); // Применяем изменения
    }

    // Внутренний класс для обработки кликов по кнопкам игрового поля
    private class ButtonClickListener implements View.OnClickListener {
        private int position; // Позиция кнопки

        // Конструктор, принимающий позицию кнопки
        public ButtonClickListener(int position) {
            this.position = position;
        }

        @Override
        public void onClick(View v) {
            makeMove(position); // Выполняем ход по нажатию на кнопку
        }
    }
}
